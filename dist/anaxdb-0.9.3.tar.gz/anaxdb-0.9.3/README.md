# AnaxDb
<i>An encrypted non-linear database based on Pandas</i>

For more details please see the examples <a href="https://github.com/abrahamrhoffman/AnaxDb/tree/master/examples">here</a>

### Install AnaxDb

```
git clone https://github.com/abrahamrhoffman/AnaxDb.git
cd AnaxDb
pip install -r requirements.txt
```

### Usage

```
import anaxdb
```
